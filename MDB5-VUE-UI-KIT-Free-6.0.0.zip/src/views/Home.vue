<template>
  <HelloWorld
    msg="Thank you for using our product. We're glad you're with us."
  />
</template>

<script setup lang="ts">
import HelloWorld from "../components/HelloWorld.vue";
</script>
